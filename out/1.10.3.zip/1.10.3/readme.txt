If you need help on how to use the Tibia Auto, please take a look at http://wiki.tibiaauto.net/ for the full
users' manual.

NOTE: If you experiance a missing python24.dll or msvcrt71.dll then install Python from http://www.python.org/